This project runs on Python 2.7.

It uses numpy, matplotlib, pandas, and makes extensive use of the Sci-Kit Learn library.

The EDA IPython notebook produces a modified dataset which can then be used to run the regression.